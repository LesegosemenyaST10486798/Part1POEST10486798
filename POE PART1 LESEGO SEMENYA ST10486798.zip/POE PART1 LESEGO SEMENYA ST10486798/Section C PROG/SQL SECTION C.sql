/*
 RaceDay - Part 1 SQL Server Database Script
 Target: Microsoft SQL Server / SSMS
*/
IF DB_ID(N'RaceDayDB') IS NULL
BEGIN
    CREATE DATABASE RaceDayDB;
END;
GO
USE RaceDayDB;
GO
-- Drop in dependency order so the script can be re-run during testing.
IF OBJECT_ID('dbo.Results','U') IS NOT NULL DROP TABLE dbo.Results;
IF OBJECT_ID('dbo.Enrollments','U') IS NOT NULL DROP TABLE dbo.Enrollments;
IF OBJECT_ID('dbo.EventCategories','U') IS NOT NULL DROP TABLE dbo.EventCategories;
IF OBJECT_ID('dbo.Categories','U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID('dbo.Events','U') IS NOT NULL DROP TABLE dbo.Events;
IF OBJECT_ID('dbo.Users','U') IS NOT NULL DROP TABLE dbo.Users; IF OBJECT_ID('dbo.Roles','U') IS NOT NULL DROP TABLE dbo.Roles;
GO
CREATE TABLE dbo.Roles
(
    RoleID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Roles PRIMARY KEY,
    RoleName NVARCHAR(30) NOT NULL
        CONSTRAINT UQ_Roles_RoleName UNIQUE,
    Description NVARCHAR(200) NULL
);
GO
CREATE TABLE dbo.Users
(
    UserID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Users PRIMARY KEY,
    RoleID INT NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) NOT NULL
        CONSTRAINT UQ_Users_Email UNIQUE,     PasswordHash NVARCHAR(255) NOT NULL,
    Phone NVARCHAR(30) NULL,
    CreatedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Users_Roles         FOREIGN KEY (RoleID) REFERENCES dbo.Roles(RoleID)
);
GO
CREATE TABLE dbo.Events
(
    EventID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Events PRIMARY KEY,
    OrganizerID INT NOT NULL,
    EventName NVARCHAR(150) NOT NULL,
    EventType NVARCHAR(30) NOT NULL,
    EventDate DATE NOT NULL,
    StartTime TIME(0) NOT NULL,
    Location NVARCHAR(200) NOT NULL,
    RouteInfo NVARCHAR(500) NULL,
    WeatherInfo NVARCHAR(500) NULL,
    Status NVARCHAR(30) NOT NULL         CONSTRAINT DF_Events_Status DEFAULT N'Upcoming',
    CONSTRAINT FK_Events_Organizer         FOREIGN KEY (OrganizerID) REFERENCES dbo.Users(UserID),
    CONSTRAINT CK_Events_EventType
        CHECK (EventType IN (N'Running',N'Walking',N'Cycling')),
    CONSTRAINT CK_Events_Status
        CHECK (Status IN (N'Draft',N'Upcoming',N'Completed',N'Cancelled'))
);
GO
CREATE TABLE dbo.Categories
(
    CategoryID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Categories PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL,
    DistanceKm DECIMAL(5,2) NOT NULL,
    MaxParticipants INT NULL,
    CONSTRAINT UQ_Categories_NameDistance
        UNIQUE (CategoryName, DistanceKm),
    CONSTRAINT CK_Categories_Distance CHECK (DistanceKm > 0),
    CONSTRAINT CK_Categories_MaxParticipants
        CHECK (MaxParticipants IS NULL OR MaxParticipants > 0)
);
GO
CREATE TABLE dbo.EventCategories
(
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    EntryFee DECIMAL(10,2) NOT NULL
        CONSTRAINT DF_EventCategories_EntryFee DEFAULT (0),
    Capacity INT NULL,
    CONSTRAINT PK_EventCategories PRIMARY KEY (EventID, CategoryID),
    CONSTRAINT FK_EventCategories_Events
        FOREIGN KEY (EventID) REFERENCES dbo.Events(EventID),
    CONSTRAINT FK_EventCategories_Categories
        FOREIGN KEY (CategoryID) REFERENCES dbo.Categories(CategoryID),
    CONSTRAINT CK_EventCategories_EntryFee CHECK (EntryFee >= 0),
    CONSTRAINT CK_EventCategories_Capacity
        CHECK (Capacity IS NULL OR Capacity > 0)
);
GO
CREATE TABLE dbo.Enrollments
(
    EnrollmentID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Enrollments PRIMARY KEY,
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    ParticipantID INT NOT NULL,
    EnrollmentDate DATETIME2(0) NOT NULL
        CONSTRAINT DF_Enrollments_EnrollmentDate DEFAULT SYSUTCDATETIME(),
    Status NVARCHAR(30) NOT NULL
        CONSTRAINT DF_Enrollments_Status DEFAULT N'Confirmed',
    RaceNumber NVARCHAR(20) NULL
        CONSTRAINT UQ_Enrollments_RaceNumber UNIQUE,
    CONSTRAINT FK_Enrollments_EventCategory
        FOREIGN KEY (EventID, CategoryID)
        REFERENCES dbo.EventCategories(EventID, CategoryID),
    CONSTRAINT FK_Enrollments_Participant
        FOREIGN KEY (ParticipantID) REFERENCES dbo.Users(UserID),
    CONSTRAINT CK_Enrollments_Status         CHECK (Status IN (N'Pending',N'Confirmed',N'Cancelled',N'Completed'))
);
GO
CREATE TABLE dbo.Results
(
    ResultID INT IDENTITY(1,1) NOT NULL
        CONSTRAINT PK_Results PRIMARY KEY,
    EnrollmentID INT NOT NULL         CONSTRAINT UQ_Results_Enrollment UNIQUE,
    FinishTime TIME(0) NULL,
    Position INT NULL,
    Pace DECIMAL(6,2) NULL,
    RecordedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Results_RecordedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Results_Enrollment
        FOREIGN KEY (EnrollmentID) REFERENCES dbo.Enrollments(EnrollmentID),
    CONSTRAINT CK_Results_Position
        CHECK (Position IS NULL OR Position > 0),
    CONSTRAINT CK_Results_Pace
        CHECK (Pace IS NULL OR Pace > 0)
);
GO
-- Roles
INSERT INTO dbo.Roles (RoleName, Description)
VALUES
(N'Organizer', N'Creates and manages events, categories and results.'),
(N'Participant', N'Browses events, enrolls and views personal results.');
GO
-- Two organisers and two participants minimum
INSERT INTO dbo.Users (RoleID, FullName, Email, PasswordHash, Phone)
SELECT RoleID, N'Naledi Mokoena', N'naledi@raceday.example', N'HASH_PLACEHOLDER_1', N'0710000001'
FROM dbo.Roles WHERE RoleName = N'Organizer';
INSERT INTO dbo.Users (RoleID, FullName, Email, PasswordHash, Phone)
SELECT RoleID, N'Thabo Dlamini', N'thabo@raceday.example', N'HASH_PLACEHOLDER_2', N'0710000002'
FROM dbo.Roles WHERE RoleName = N'Organizer';
INSERT INTO dbo.Users (RoleID, FullName, Email, PasswordHash, Phone)
SELECT RoleID, N'Ayesha Naidoo', N'ayesha@raceday.example', N'HASH_PLACEHOLDER_3', N'0710000003'
FROM dbo.Roles WHERE RoleName = N'Participant';
INSERT INTO dbo.Users (RoleID, FullName, Email, PasswordHash, Phone)
SELECT RoleID, N'Kabelo Maseko', N'kabelo@raceday.example', N'HASH_PLACEHOLDER_4', N'0710000004'
FROM dbo.Roles WHERE RoleName = N'Participant';
GO
-- Three events
INSERT INTO dbo.Events
(OrganizerID, EventName, EventType, EventDate, StartTime, Location, RouteInfo, WeatherInfo)
SELECT u.UserID, N'Johannesburg Spring 10K', N'Running', '2026-09-20', '07:00',
       N'Johannesburg, Gauteng',
       N'10 km city route; water points at 3 km, 6 km and 8 km.',
       N'Check forecast 24 hours before event.' FROM dbo.Users u WHERE u.Email = N'naledi@raceday.example';
INSERT INTO dbo.Events
(OrganizerID, EventName, EventType, EventDate, StartTime, Location, RouteInfo, WeatherInfo)
SELECT u.UserID, N'Soweto Community Walk', N'Walking', '2026-10-04', '08:00',
       N'Soweto, Gauteng',
       N'5 km community route with marshalled crossings.',
       N'Check forecast 24 hours before event.' FROM dbo.Users u WHERE u.Email = N'thabo@raceday.example';
INSERT INTO dbo.Events
(OrganizerID, EventName, EventType, EventDate, StartTime, Location, RouteInfo, WeatherInfo)
SELECT u.UserID, N'Cradle Cycle Challenge', N'Cycling', '2026-10-18', '06:30',
       N'Cradle of Humankind, Gauteng',
       N'40 km cycling route with designated support points.',
       N'Check wind and temperature before race day.' FROM dbo.Users u WHERE u.Email = N'naledi@raceday.example';
GO
-- Categories
INSERT INTO dbo.Categories (CategoryName, DistanceKm, MaxParticipants)
VALUES
(N'10K Run', 10.00, 1000),
(N'5K Walk', 5.00, 700),
(N'40K Cycle', 40.00, 500),
(N'Fun Run', 5.00, 500), (N'Junior Cycle', 10.00, 250);
GO
-- Attach categories to events
INSERT INTO dbo.EventCategories (EventID, CategoryID, EntryFee, Capacity)
SELECT e.EventID, c.CategoryID, 150.00, 1000
FROM dbo.Events e CROSS JOIN dbo.Categories c
WHERE e.EventName = N'Johannesburg Spring 10K' AND c.CategoryName = N'10K Run';
INSERT INTO dbo.EventCategories (EventID, CategoryID, EntryFee, Capacity)
SELECT e.EventID, c.CategoryID, 80.00, 700
FROM dbo.Events e CROSS JOIN dbo.Categories c
WHERE e.EventName = N'Soweto Community Walk' AND c.CategoryName = N'5K Walk';
INSERT INTO dbo.EventCategories (EventID, CategoryID, EntryFee, Capacity)
SELECT e.EventID, c.CategoryID, 250.00, 500
FROM dbo.Events e CROSS JOIN dbo.Categories c
WHERE e.EventName = N'Cradle Cycle Challenge' AND c.CategoryName = N'40K Cycle';
GO
-- Sample enrolments
INSERT INTO dbo.Enrollments (EventID, CategoryID, ParticipantID, Status, RaceNumber)
SELECT ec.EventID, ec.CategoryID, u.UserID, N'Confirmed', N'RD1001'
FROM dbo.EventCategories ec
JOIN dbo.Events e ON e.EventID = ec.EventID
JOIN dbo.Categories c ON c.CategoryID = ec.CategoryID
JOIN dbo.Users u ON u.Email = N'ayesha@raceday.example'
WHERE e.EventName = N'Johannesburg Spring 10K'
  AND c.CategoryName = N'10K Run';
INSERT INTO dbo.Enrollments (EventID, CategoryID, ParticipantID, Status, RaceNumber)
SELECT ec.EventID, ec.CategoryID, u.UserID, N'Confirmed', N'RD1002'
FROM dbo.EventCategories ec
JOIN dbo.Events e ON e.EventID = ec.EventID
JOIN dbo.Categories c ON c.CategoryID = ec.CategoryID
JOIN dbo.Users u ON u.Email = N'kabelo@raceday.example'
WHERE e.EventName = N'Johannesburg Spring 10K'
  AND c.CategoryName = N'10K Run';
INSERT INTO dbo.Enrollments (EventID, CategoryID, ParticipantID, Status, RaceNumber)
SELECT ec.EventID, ec.CategoryID, u.UserID, N'Confirmed', N'RD2001'
FROM dbo.EventCategories ec
JOIN dbo.Events e ON e.EventID = ec.EventID
JOIN dbo.Categories c ON c.CategoryID = ec.CategoryID
JOIN dbo.Users u ON u.Email = N'ayesha@raceday.example'
WHERE e.EventName = N'Soweto Community Walk'
  AND c.CategoryName = N'5K Walk';
GO
-- Sample results
INSERT INTO dbo.Results (EnrollmentID, FinishTime, Position, Pace)
SELECT TOP (1) EnrollmentID, '00:52:31', 1, 5.25
FROM dbo.Enrollments
WHERE RaceNumber = N'RD1001';
INSERT INTO dbo.Results (EnrollmentID, FinishTime, Position, Pace)
SELECT TOP (1) EnrollmentID, '00:58:12', 2, 5.82
FROM dbo.Enrollments WHERE RaceNumber = N'RD1002';
